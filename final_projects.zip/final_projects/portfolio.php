<!-- ---------------------- Start Portfolio Section --------------------- -->
<section id="port_section">
    <div class="container">
        <div class="row">
            <div class="col portfolio_head">
                <h1>Portfolio</h1>
            </div>
        </div>
        <div class="row">
            <div class="col portfolio_para">
                <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-4 offset-4 port_col">
                <nav id="portfolio_navbar">
                    <ul>
                        <li><a href="#">All</a></li>
                        <li><a href="#">App</a></li>
                        <li><a href="#">Card</a></li>
                        <li><a href="#">Web</a></li>
                    </ul>
                </nav>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-lg-4 mb-4 port_image">
                <img src="assets/images/portfolio/portfolio-1.jpg" alt="portfolio-1">
                <div class="img_app">
                    <h4 class="app">App 1</h4>
                    <p class="app">App</p>
                    <a href="#"><i class="fa-solid fa-link"></i></a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 port_image">
                <img src="assets/images/portfolio/portfolio-2.jpg" alt="portfolio-2">
                <div class="img_app">
                    <h4 class="app">Web 1</h4>
                    <p class="app">Web</p>
                    <a href="#"><i class="fa-solid fa-link"></i></a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 port_image">
                <img src="assets/images/portfolio/portfolio-3.jpg" alt="portfolio-3">
                <div class="img_app">
                    <h4 class="app">App 2</h4>
                    <p class="app">App</p>
                    <a href="#"><i class="fa-solid fa-link"></i></a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 port_image">
                <img src="assets/images/portfolio/portfolio-4.jpg" alt="portfolio-4">
                <div class="img_app">
                    <h4 class="app">Card 2</h4>
                    <p class="app">Card</p>
                    <a href="#"><i class="fa-solid fa-link"></i></a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 port_image">
                <img src="assets/images/portfolio/portfolio-5.jpg" alt="portfolio-5">
                <div class="img_app">
                    <h4 class="app">Web 2</h4>
                    <p class="app">Web</p>
                    <a href="#"><i class="fa-solid fa-link"></i></a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 port_image">
                <img src="assets/images/portfolio/portfolio-6.jpg" alt="portfolio-6">
                <div class="img_app">
                    <h4 class="app">App 3</h4>
                    <p class="app">App</p>
                    <a href="#"><i class="fa-solid fa-link"></i></a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 port_image">
                <img src="assets/images/portfolio/portfolio-7.jpg" alt="portfolio-7">
                <div class="img_app">
                    <h4 class="app">Card 1</h4>
                    <p class="app">Card</p>
                    <a href="#"><i class="fa-solid fa-link"></i></a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 port_image">
                <img src="assets/images/portfolio/portfolio-8.jpg" alt="portfolio-8">
                <div class="img_app">
                    <h4 class="app">Card 3</h4>
                    <p class="app">Card</p>
                    <a href="#"><i class="fa-solid fa-link"></i></a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 port_image">
                <img src="assets/images/portfolio/portfolio-9.jpg" alt="portfolio-9">
                <div class="img_app">
                    <h4 class="app">Web 3</h4>
                    <p class="app">Web</p>
                    <a href="#"><i class="fa-solid fa-link"></i></a>
                </div>
            </div>     
        </div>
    </div>
</section>

        <!-- ---------------------- End Portfolio Section --------------------- -->