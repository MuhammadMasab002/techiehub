<!-- ----------------------- Start Contact Section ------------------------ -->
<section id="contact_section">
    <div class="container">
        <div class="row">
            <div class="col contact_head">
                <h1>Contact</h1>
            </div>
        </div>
        <div class="row">
            <div class="col contact_para">
                <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 mt-4">
                <div class="contact_left">
                    <div class="contact_location">
                        <i class="fa-solid fa-location-dot"></i>
                        <div>
                            <h4>Location:</h4>
                            <p>A108 Adam Street, New York, NY 535022</p>
                        </div>
                    </div>
                </div>
                <div class="contact_left">
                    <div class="contact_location">
                        <i class="fa-regular fa-envelope"></i>
                        <div>
                            <h4>Email:</h4>
                            <p>info@techiehub.com</p>
                        </div>
                    </div>
                </div>
                <div class="contact_left">
                    <div class="contact_location">
                        <i class="fa-solid fa-mobile-screen-button"></i>
                        <div>
                            <h4>Call:</h4>
                            <p>+1 5589 55488 55s</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-8 mt-4">
                <div id="contact_right">
                    <div class="row g-3">
                        <div class="col-12 form_head">
                            <h1>Contact form</h1>
                            <p>Or, you can just send an email: <a href="#">info@techiehub.com</a></p>
                        </div>

                        <form>
                            <div class="row g-3">
                                <div class="col-lg-4 col-sm-10 offset-lg-2 offset-sm-1 contact_form">
                                    <input type="text" name="fname" class="form_input" id="fname" placeholder="First Name">
                                </div>
                                <div class="col-lg-4 col-sm-10 offset-lg-0 offset-sm-1 contact_form">
                                    <input type="text" name="flname" class="form_input" id="lname" placeholder="Last Name">
                                </div>
                                <div class="col-lg-8 col-sm-10 offset-lg-2 offset-sm-1 contact_form">
                                    <input type="email" name="email" class="form_input" id="email" placeholder="Email Address">
                                </div>
                                <div class="col-lg-8 col-sm-10 offset-lg-2 offset-sm-1 contact_form">
                                    <textarea name="text_area" class="form_input" id="text_area" cols="30" rows="4"></textarea>
                                </div>
                                <div class="col-12 col-lg-8 offset-lg-2 contact_form" id="form_btn">
                                    <input class="btn" type="submit" value="Send Message">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- -------------------------- End Contact Section ---------------------- -->