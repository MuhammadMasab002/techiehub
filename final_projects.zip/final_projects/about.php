<!-- -------------- Start About Section -------------- -->
<section id="about">
    <div class="container  mt-lg-5 mb-5">
        <div class="row">
            <div class="col about_head">
                <h1>ABOUT</h1>
            </div>
        </div>
        <div class="row">
            <div class="col about_para">
                <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea.</p>
            </div>
        </div>

        <div class="row no-gutters">
            <div class="col-lg-6 mt-4 mb-4 about_left">
                <h1>They provide most valuable pleasure as it were</h1>
                <div class="img">
                    <img src="assets/images/about/group-people-volunteering-foodbank-poor-people.jpg" alt="group-people-volunteering-foodbank-poor-people">
                    <a href="about-details.php">ABOUT US</a>
                </div>
                
            </div>
            <div class="col-lg ms-md-2 mt-4 mt-lg-5 about_right">
                <div class="p-4 mb-4 about_right_top">
                    <h1>Our Story</h1>
                    <h3>Let it be the Pleasures of the Body</h3>
                    <p class="pe-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit</p>
                </div>
                <div class="row ms-1 me-1 mt-4">
                    <div class="col-md p-4 me-3 mb-4  about_right_bottom">
                        <h3>Work consequatur</h3>
                        <p>Expedita veritatis consequuntur nihil tempore laudantium vitae denat pacta</p>
                    </div>
                    <div class="col-md p-4 ms-md-3 mb-4 about_right_bottom">
                        <h3>Beatae veritatis</h3>
                        <p>Aut suscipit aut cum nemo deleniti aut omnis. Doloribus ut maiores omnis facere</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- --------------- End About Section --------------- -->

<!-- --------------- Start Count Section --------------- -->
<section id="counter_section">
    <div class="container pt-2 pb-5">
        <div class="row">
            <div class="col-md-6 col-lg mt-5">
                <div class="counter">
                    <i class="bi bi-emoji-smile"></i>
                    <h2>111</h2>
                    <p>Happy Clients</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3  mt-5">
                <div class="counter">
                    <i class="bi bi-journal-richtext"></i>
                    <h2>150</h2>
                    <p>Projects</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3  mt-5">
                <div class="counter">
                    <i class="bi bi-headset"></i>
                    <h2>1247</h2>
                    <p>Hours Of Support</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3  mt-5">
                <div class="counter">
                    <i class="bi bi-people"></i>
                    <h2>12</h2>
                    <p>Hard Workers</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- --------------- End Count Section --------------- -->
