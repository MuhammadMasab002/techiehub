<!-- -------------------------- Start Footer Section ---------------------------- -->
<footer id="footer_section">
    <div id="footer_top">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-sm-6 col-12">
                    <div class="footer_logo">
                        <h2>
                            <a href="index_page.php">
                                Techie Hub<span>.</span> 
                            </a>
                        </h2>
                        <p>
                            A108 Adam Street <br>
                            New York, NY 535022 <br>
                            United States
                        </p>
                        <p>
                            <span>Phone:</span>
                            +1 5589 55488 55
                        </p>
                        <p>
                            <span>Email:</span>
                            info@techiehub.com
                        </p>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 col-12">
                    <div class="footer_nav">
                        <h4>Useful Links</h4>
                        <nav class="footer_links">
                            <ul>
                                <li>
                                    <i class="fa-solid fa-chevron-right"></i>
                                    <a class="footerNav" href="index_page.php">Home</a>
                                </li>
                                <li>
                                    <i class="fa-solid fa-chevron-right"></i>
                                    <a class="footerNav" href="about-details.php">About US</a>
                                </li>
                                <li>
                                    <i class="fa-solid fa-chevron-right"></i>
                                    <a class="footerNav" href="#">Blog</a>
                                </li>
                                <li>
                                    <i class="fa-solid fa-chevron-right"></i>
                                    <a class="footerNav" href="#">Terms of service</a>
                                </li>
                                <li>
                                    <i class="fa-solid fa-chevron-right"></i>
                                    <a class="footerNav" href="#">Privacy policy</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-9 col-12">
                    <div class="footer_nav footer_email">
                        <h4>Join Our Newsletter</h4>
                        <p>Tamen quem nulla quae legam multos aute sint culpa legam noster magna</p>
                        <form>
                            <div class="input-group footer_form">
                                <input class="form-control" type="email" name="email" id="email">
                                <input class="form-control" type="submit" value="Subscribe" id="submit">
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
    
    <div class="container">
        <div class="row">
            <div class="col footer_bottom ms-sm-2 ms-3 me-sm-2 me-3">
                <div class="footer_copyright">
                    <p> © Copyright <span> Techie hub. </span> All Rights Reserved </p>
                    <span>Designed by</span>
                    <a href="#">BootstrapMade bala bala</a>
                </div>
                <div class="footer_social">
                    <a href="#"><i class="fa-brands fa-twitter"></i></a>
                    <a href="#"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>
        
<!-- --------------------------- End Footer Section ----------------------------- -->