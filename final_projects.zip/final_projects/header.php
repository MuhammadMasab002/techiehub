
<!-- start header section -->
<header class="sticky-top">
    <div class="container">
        <div class="row">
            <div class="wapper">
                <div class="col">
                    <h1>
                        <a href="index_page.php">
                            Techie Hub<span>.</span> 
                        </a>
                    </h1>
                </div>

                <!-- start navbar section -->
                <div class="col-lg-6">
                    <nav class="navbar">
                        <ul>
                            <li><a class="active" href="index_page.php">Home</a></li>
                            <li><a href="about-details.php">About</a></li>
                            <li><a href="portfolio-details.php">Portfolio</a></li>
                            <li><a href="team-details.php">Team</a></li>
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Drop Down</a></li>
                            <li><a href="contact-details.php">Contact</a></li>
                        </ul>
                    </nav>
                </div><!-- end navbar section -->

                <div class="col">
                    <div class="get_started">
                        <a href="#">Get Started</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header><!-- end header section -->