 <!-- Start Hero Section -->
 <section class="hero_section pt-5">
   <div class="container d-flex">
      <div class="row">
         <div class="col-xl-7 hero_col">
            <h1>Bettter digital experience with Techie</h1>
            <h2>We are team of talented designers making websites with Bootstrap</h2>
            <a href="#">Get Started</a>
         </div>
      </div>
   </div>
 </section>
    <!-- End Hero Section -->

