<!-- ----------------------- Start Team Section ---------------------- -->
<section id="team_section">
    <div class="container pb-5">
        <div class="row">
            <div class="col team_head">
                <h1>Team</h1>
            </div>
        </div>
        <div class="row">
            <div class="col team_para">
                <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea.</p>
            </div>
        </div>
        <div class="row">

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="member">
                    <div class="team_image">
                        <img src="assets/images/team/team-1.jpg" alt="team-1">
                        <div class="team_social">
                            <a href="#"><i class="fa-brands fa-twitter"></i></a>
                            <a href="#"><i class="fa-brands fa-facebook"></i></a>
                            <a href="#"><i class="fa-brands fa-instagram"></i></a>
                            <a href="#"><i class="fa-brands fa-linkedin"></i></a>
                        </div>
                    </div>
                    <div class="team_name">
                        <h5>Walter White</h5>
                        <p>Chief Executive Officer</p>
                        <p>Magni qui quod omnis unde et eos fuga et exercitationem. Odio veritatis perspiciatis quaerat qui aut aut aut</p>
                        <a href="#">Get Started</a>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="member">
                    <div class="team_image">
                        <img src="assets/images/team/team-2.jpg" alt="team-2">
                        <div class="team_social">
                            <a href="#"><i class="fa-brands fa-twitter"></i></a>
                            <a href="#"><i class="fa-brands fa-facebook"></i></a>
                            <a href="#"><i class="fa-brands fa-instagram"></i></a>
                            <a href="#"><i class="fa-brands fa-linkedin"></i></a>
                        </div>
                    </div>
                    <div class="team_name">
                        <h5>Sarah Jhonson</h5>
                        <p>Product Manager</p>
                        <p>Repellat fugiat adipisci nemo nesciunt voluptas repellendus. In nemo illum nesciunt architecto rerum rerum temporibus</p>
                        <a href="#">Get Started</a>
                    </div>
                </div>
            </div>

            <div class="col-md-12 col-lg-4 mb-3">
                <div class="row member">
                    <div class="col-md col-lg-12 team_image team_image_3">
                        <img src="assets/images/team/team-3.jpg" alt="team-3">
                        <div class="team_social">
                            <a href="#"><i class="fa-brands fa-twitter"></i></a>
                            <a href="#"><i class="fa-brands fa-facebook"></i></a>
                            <a href="#"><i class="fa-brands fa-instagram"></i></a>
                            <a href="#"><i class="fa-brands fa-linkedin"></i></a>
                        </div>
                    </div>
                    <div class="col-md col-lg-12 team_name team_name_3">
                        <h5>William Anderson</h5>
                        <p>CEO</p>
                        <p>Voluptas necessitatibus occaecati. Earum totam consequuntur qui porro et totam laborum porro et tue toro des clara</p>
                        <a href="#">Get Started</a>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>
<!-- ----------------------- End Team Section ---------------------- -->